using System;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.Metrics;
using Npgsql.EntityFrameworkCore.PostgreSQL.Storage.Internal.Mapping;
using NpgsqlTypes;

namespace JoJoBAr
{
    public class Product_in_stock
    {
        [Key]
        public int Id_product_in_stock { get; set; }
        public string Product_name { get; set; }
        public NpgsqlTimestampTypeMapping Supply_date { get; set; }
        public NpgsqlInterval Expiration_date { get; set; }
        public double Quantity { get; set; }

        public int Id_measure { get; set; }
        public string Photo { get; set; }
        public Measure Measure_entity { get; set; }
        public List<Food_and_product> Food_and_product_entities { get; set; }
    }
}
