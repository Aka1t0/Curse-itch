using System;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JoJoBAr
{
    public class Measure
    {
        [Key]
        public int Id_measure { get; set; }
        public string Measure_name { get; set; }
        public List<Food_and_product> Food_and_product_entities { get; set; }
        public List<Product_in_stock> Product_in_stock_entities { get; set; }
        public List<Food> Food_entities { get; set; }
    }
}
