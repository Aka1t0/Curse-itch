using System;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using NpgsqlTypes;

namespace JoJoBAr
{
    public class User
    {
        [Key]
        public int Id_user { get; set; }
        public string FIO { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public string Phone { get; set; }
        public string Position { get; set; }
        public double Salary { get; set; }
        public NpgsqlInterval Experience { get; set; }
        public string Photo { get; set; }
        public List<Order> Order_entities { get; set; }
    }
}
