using System;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JoJoBAr
{
    public class Order
    {
        [Key]
        public int Id_order { get; set; }

        [ForeignKey("Table_entity")]
        public int Id_table { get; set; }

        [ForeignKey("Client_card_entity")]
        public int Id_client_card { get; set; }

        [ForeignKey("User_entity")]
        public int Id_user { get; set; }
        public User User_entity { get; set; }
        public Table Table_entity { get; set; }
        public Client_card Client_card_entity { get; set; }
        
        public List<Order_and_food> Order_and_food_entities { get; set; }

    }
}
