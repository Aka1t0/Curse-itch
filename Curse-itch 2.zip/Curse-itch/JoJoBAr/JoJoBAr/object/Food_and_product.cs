﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JoJoBAr
{
    public class Food_and_product
    {
        [Key]
        public int Id_food_and_product { get; set; }

        [ForeignKey ("Product_in_stock_entity")]
        public int Id_product_in_stock { get; set; }

        [ForeignKey ("Food_entity")]
        public int Id_food { get; set; }
        public int Product_in_food { get; set; }
        [ForeignKey ("Measure_entity")]
        public int Id_measure { get; set; }
        public Measure Measure_entity { get; set; }
        public Food Food_entity { get; set; }
        public Product_in_stock Product_in_stock_entity { get; set; }
    }
}
