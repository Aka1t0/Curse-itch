﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace JoJoBAr
{
    public static class DatabaseControl
    {
        public static List<User> GetUsersForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.User.ToList();
            }
        }

        public static void AddUser(User user)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.User.Add(user);
                ctx.SaveChanges();
            }
        }

        public static List<Client_card> GetClientCardsForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Client_card.ToList();
            }
        }

        public static List<Food> GetFoodsForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Food.Include(f => f.Measure_entity).ToList();
            }
        }

        public static List<Product_in_stock> GetProductsInStockForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Product_in_stock.Include(p => p.Measure_entity).ToList(); 
            }
        }

        public static List<Table> GetTablesForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Table.ToList();
            }
        }

        public static List<Order> GetOrdersForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Order.Include(o => o.User_entity).Include(o => o.Client_card_entity).Include(o => o.Table_entity).ToList();
            }
        }



        /* public static void AddOrder(Order order)
         {
             using(DbAppContext ctx = new DbAppContext())
             {
                 ctx.Orders.Add(order);
                 ctx.SaveChanges();
             }
         }
         public static void UpdateOrder(Order order) 
         {
             using (DbAppContext ctx = new DbAppContext())
             {
                 Order _order = ctx.Orders.FirstOrDefault(o => o.Id_order == o.Id_order);

                 _order.Id_table = order.Id_table;
                 _order.Id_client_card = order.Id_client_card;
                 _order.Id_user = order.Id_user;

                 ctx.SaveChanges();
             }
         }*/

    }
}
