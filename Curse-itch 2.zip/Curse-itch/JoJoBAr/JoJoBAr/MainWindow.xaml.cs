﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JoJoBAr
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public List<User> users;

        private void button_Enter_Click(object sender, RoutedEventArgs e)
        {
            users = DatabaseControl.GetUsersForView();

            if (textBox_login.Text.Length > 0 && password.Password.Length > 0)
            {
                IEnumerable<User> user = users.Where(p => p.Login == textBox_login.Text && p.Password == password.Password);

                if (user.Count() > 0)
                {
                    User dbUser = user.First();

                    BarthunderWindow barthunderWindow = new BarthunderWindow();
                    barthunderWindow.Show();
                    Close();
                }
                else
                {
                    MessageBox.Show("Неправильный логин или пароль");
                }
            } else
            {
                MessageBox.Show("Введите логин и пароль");
            }
            
        }

        private void button_Registration_Click(object sender, RoutedEventArgs e)
        {
            RegistrationWindow registrationWindow = new RegistrationWindow();
            registrationWindow.Show();
        }
    }
}
