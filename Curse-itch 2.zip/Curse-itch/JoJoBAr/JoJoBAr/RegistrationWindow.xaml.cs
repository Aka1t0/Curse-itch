﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace JoJoBAr
{
    /// <summary>
    /// Логика взаимодействия для RegistrationWindow.xaml
    /// </summary>
    public partial class RegistrationWindow : Window
    {
        public RegistrationWindow()
        {
            InitializeComponent();
        }
        public List<User> users;

        private void button_registration_end_Click(object sender, RoutedEventArgs e)
        {
            users = DatabaseControl.GetUsersForView();

            if (textBox_login.Text.Length > 0 && password.Password.Length > 0)
            {
                if (password.Password.Length == password_copy.Password.Length)
                {
                    DatabaseControl.AddUser(new User
                    {
                        Login = textBox_login.Text,
                        Password = password.Password.ToString(),
                        FIO = textBox_FIO.Text,
                        Phone = textBox_phone.Text,
                        Position = textBox_position.Text,
                        Experience = "0 years",
                        Photo = "..'\\JoJoBAr\\image\\user\\default.png"
                    });
                    MessageBox.Show("Регистрация пройдена успешно!");
                    Close();
                }
                else
                {
                    MessageBox.Show("Пароли не совпадают");
                }
            }
            else
            {
                MessageBox.Show("Введите логин и пароль");
            }
        }

        private void button_back_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
