INSERT INTO "Client_card"("FIO", "Phone", "Bonus")
VALUES
('Сердюк Михаил Сергеевич','+7(912)383-46-23',4.34),
('Домитори Спи Цын','+7(912)455-76-67',40.09),
('Ли Си Цин','+7(912)498-80-22',42.69),
('Кондинция Константин Кириллович','+7(912)132-46-98',98.3);

INSERT INTO "Table"("Reservation_time_start", "Reservation_interval", "Reserved")
VALUES
('2023-06-01 19:00:00','2 hours', false),
('2023-06-01 23:00:00','4 hours', false),
('2023-06-02 17:30:00','4 hours', false),
('2023-06-02 19:00:00','3 hours', false);


INSERT INTO "User"("FIO", "Login", "Password", "Phone", "Position", "Salary", "Experience")
VALUES
('Жоск Жори Женевич', 'worker', 'password','+7(912)323-22-24', 'Официант', 30000.00, '2 YEARS 6 MONTHS'),
('Ивакура Лейн Кодовна', 'admin', 'admin','+7(912)242-76-26', 'Сист. админ', 60000.00, '5 YEARS'),
('Стингер Джулианна Пивановна', 'worker', 'password','+7(912)383-46-23', 'Бармен', 30000.00, '2 YEARS 6 MONTHS'),
('Труссарди Тонио Гордонович', 'worker', 'password','+7(800)555-35-35', 'Шеф-повар', 57500.00, '12 YEARS'),
('Фринг Густаво Сандерсович', 'worker', 'password','+7(912)383-46-23', 'Менеджер', 30000.00, '2 YEARS 6 MONTHS');


INSERT INTO "Food"("Food_name", "Cooking_time", "Definition", "Cooking_place", "Weight", "Id_measure", "Price")
VALUES
('Паста Болонеза', '45 minutes', 'Итальянская паста с мясным соусом болонеза', false, 0.200, 5, 300.00),
('Мохито', '10 minutes', 'Легкий алкогольный коктейл', true, 0.200, 6, 160.00),
('Секс на пляже', '5 minutes', 'Классика из мира коктейлей', false, 0.140, 6, 150.00);


INSERT INTO "Product_in_stock"("Product_name", "Supply_date", "Expiration_date", "Quantity", "Id_measure")
VALUES
('Barilla Макароны Bavette', '2023-05-14 09:34:20', '3 months', 10.200, 5),
('Фарш Мотоциклический', '2023-05-14 09:34:20', '3 months', 10.200, 5),
('Кетчуп Тарантиновский', '2023-05-14 09:34:20', '12 months', 24.400, 6),
('Водка Клюква', '2023-05-14 09:34:20', '30 months', 40.000, 6);