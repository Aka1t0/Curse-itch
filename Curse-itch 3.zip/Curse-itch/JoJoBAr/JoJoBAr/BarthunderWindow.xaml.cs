﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using JoJoBAr.window;

namespace JoJoBAr
{
    /// <summary>
    /// Логика взаимодействия для BarthunderWindow.xaml
    /// </summary>
    public partial class BarthunderWindow : Window
    {

        public MainWindow mainWindow;
        public BarthunderWindow()
        {
            InitializeComponent();

            ClientCardsDataGrid.ItemsSource = DatabaseControl.GetClientCardsForView();
            UsersDataGrid.ItemsSource = DatabaseControl.GetUsersForView();
            FoodsDataGrid.ItemsSource= DatabaseControl.GetFoodsForView();
            ProductsInStockDataGrid.ItemsSource = DatabaseControl.GetProductsInStockForView();
            TablesDataGrid.ItemsSource = DatabaseControl.GetTablesForView();
            OrdersDataGrid.ItemsSource = DatabaseControl.GetOrdersForView();
        }

        private void EditUserButton_Click(object sender, RoutedEventArgs e)
        {
           User user = UsersDataGrid.SelectedItem as User;

            if (user != null)
            {
                EditUserWindow window = new EditUserWindow(user);
                window.Owner = mainWindow;
                window.ShowDialog();

                RefreshUsersTable();
            }
            else
            {
                MessageBox.Show("Выберите запись для редактирования");
            }
        }

        private void DeleteUserButton_Click(object sender, RoutedEventArgs e)
        {
            User user = UsersDataGrid.SelectedItem as User;

            if (user != null)
            {
                DatabaseControl.RemoveUser(user);
                RefreshUsersTable();
            }
            else
            {
                MessageBox.Show("Выберите запись для удаления");
            }
        }

        public void RefreshUsersTable()
        {
            UsersDataGrid.ItemsSource = null;
            UsersDataGrid.ItemsSource = DatabaseControl.GetUsersForView();
        }

        private void EditFoodsButton_Click(object sender, RoutedEventArgs e)
        {
            Food food = FoodsDataGrid.SelectedItem as Food;

            if (food != null)
            {
                EditFoodWindow window = new EditFoodWindow(food);
                window.Owner = mainWindow;
                window.ShowDialog();

                RefreshFoodsTable();
            }
            else
            {
                MessageBox.Show("Выберите запись для редактирования");
            }
        }

        private void DeleteFoodButton_Click(object sender, RoutedEventArgs e)
        {
            Food food = FoodsDataGrid.SelectedItem as Food;

            if (food != null)
            {
                DatabaseControl.RemoveFood(food);
                RefreshFoodsTable();
            }
            else
            {
                MessageBox.Show("Выберите запись для удаления");
            }
        }

        public void RefreshFoodsTable()
        {
            FoodsDataGrid.ItemsSource = null;
            FoodsDataGrid.ItemsSource = DatabaseControl.GetFoodsForView();
        }
    }
}
