﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace JoJoBAr
{
    public static class DatabaseControl
    {
        public static List<User> GetUsersForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.User.ToList();
            }
        }

        public static void AddUser(User user)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.User.Add(user);
                ctx.SaveChanges();
            }
        }

        public static List<Client_card> GetClientCardsForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Client_card.ToList();
            }
        }

        public static List<Food> GetFoodsForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Food.Include(f => f.Measure_entity).ToList();
            }
        }

        public static List<Product_in_stock> GetProductsInStockForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Product_in_stock.Include(p => p.Measure_entity).ToList(); 
            }
        }

        public static List<Table> GetTablesForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Table.ToList();
            }
        }

        public static List<Order> GetOrdersForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Order.Include(o => o.User_entity).Include(o => o.Client_card_entity).Include(o => o.Table_entity).ToList();
            }
        }

        public static void UpdateUser(User user)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                User _user = ctx.User.FirstOrDefault(p => p.Id_user == user.Id_user);

                if (_user == null)
                {
                    return;
                }

                _user.FIO = user.FIO;
                _user.Login = user.Login;
                _user.Password = user.Password;
                _user.Phone = user.Phone;
                _user.Photo = user.Photo;
                _user.Salary = user.Salary;
                _user.Experience = user.Experience;
                _user.Position = user.Position;

                ctx.SaveChanges();
            }
        }


        public static void RemoveUser(User user)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                if (user == null)
                {
                    return;
                }
                ctx.User.Remove(user);
                ctx.SaveChanges();
            }
        }


        public static void UpdateFood(Food food)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                Food _food = ctx.Food.FirstOrDefault(p => p.Id_food == food.Id_food);

                if (_food == null)
                {
                    return;
                }

                _food.Food_name = food.Food_name;
                _food.Cooking_place = food.Cooking_place;
                _food.Cooking_time = food.Cooking_time;
                _food.Definition = food.Definition;
                _food.Weight = food.Weight;
                _food.Id_measure = food.Id_measure;
                _food.Price = food.Price;
                _food.Photo = food.Photo;

                ctx.SaveChanges();
            }
        }
        public static void RemoveFood(Food food)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                if (food == null)
                {
                    return;
                }
                ctx.Food.Remove(food);
                ctx.SaveChanges();
            }
        }


        /* public static void AddOrder(Order order)
         {
             using(DbAppContext ctx = new DbAppContext())
             {
                 ctx.Orders.Add(order);
                 ctx.SaveChanges();
             }
         }
         public static void UpdateOrder(Order order) 
         {
             using (DbAppContext ctx = new DbAppContext())
             {
                 Order _order = ctx.Orders.FirstOrDefault(o => o.Id_order == o.Id_order);

                 _order.Id_table = order.Id_table;
                 _order.Id_client_card = order.Id_client_card;
                 _order.Id_user = order.Id_user;

                 ctx.SaveChanges();
             }
         }*/

    }
}
