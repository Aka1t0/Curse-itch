﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace JoJoBAr.window
{
    /// <summary>
    /// Логика взаимодействия для EditUserWindow.xaml
    /// </summary>

    public partial class EditUserWindow : Window
    {
        User _tempUser;

        public EditUserWindow(User user)
        {
            InitializeComponent();
            _tempUser = user;

            textBox_login.Text = user.Login;
            textBox_FIO.Text = user.FIO;
            textBox_phone.Text = user.Phone;
            textBox_experience.Text = user.Experience;
            textBox_photo.Text = user.Photo;
            textBox_position.Text = user.Position;
            textBox_salary.Text = user.Salary.ToString();
            password.Password = user.Password;
        }
        private void userEditEndButton_Click(object sender, RoutedEventArgs e)
        {
            if (textBox_login.Text.Length > 0 && password.Password.Length > 0 && textBox_phone.Text.Length > 0 &&
                textBox_experience.Text.Length > 0 && textBox_photo.Text.Length > 0 && textBox_position.Text.Length > 0 &&
                textBox_salary.Text.Length > 0)
            {

                _tempUser.Login = textBox_login.Text;
                _tempUser.Password = password.Password.ToString();
                _tempUser.FIO = textBox_FIO.Text;
                _tempUser.Phone = textBox_phone.Text;
                _tempUser.Position = textBox_position.Text;
                _tempUser.Experience = "0 years";
                _tempUser.Photo = "..'\\JoJoBAr\\image\\user\\default.png";

                DatabaseControl.UpdateUser( _tempUser );

                MessageBox.Show("Изменения успешно внесены!");
                Close();

            }
            else
            {
                MessageBox.Show("Введены не все данные");
            }
        }

        private void userEditCancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
