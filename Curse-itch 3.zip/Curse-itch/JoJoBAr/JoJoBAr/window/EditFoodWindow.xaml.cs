﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace JoJoBAr.window
{
    /// <summary>
    /// Логика взаимодействия для EditFoodWindow.xaml
    /// </summary>

    public partial class EditFoodWindow : Window
    {
        Food _tempFood;

        public EditFoodWindow(Food food)
        {
            InitializeComponent();
            _tempFood = food;

            textBox_Food_name.Text = food.Food_name;
            textBox_Cooking_time.Text = food.Cooking_time;
            textBox_Definition.Text = food.Definition;
            checkBox_Cooking_place.IsChecked = Convert.ToBoolean(food.Cooking_place);
            textBox_Weight.Text = Convert.ToString(food.Weight);
            textBox_Measure.Text = Convert.ToString(food.Id_measure);
            textBox_Price.Text = Convert.ToString(food.Price);
            textBox_Photo.Text = food.Photo;
        }
        private void foodEditEndButton_Click(object sender, RoutedEventArgs e)
        {
            if (textBox_Food_name.Text.Length > 0 && textBox_Cooking_time.Text.Length > 0 && textBox_Definition.Text.Length > 0 &&
                textBox_Weight.Text.Length > 0 && textBox_Measure.Text.Length > 0 && textBox_Price.Text.Length > 0 &&
                textBox_Photo.Text.Length > 0)
                {


                    _tempFood.Food_name = textBox_Food_name.Text;
                    _tempFood.Cooking_time = textBox_Cooking_time.Text;
                    _tempFood.Definition = textBox_Definition.Text;
                    _tempFood.Cooking_place = Convert.ToBoolean(checkBox_Cooking_place.IsChecked);
                    _tempFood.Weight = Convert.ToDouble(textBox_Weight.Text);
                    _tempFood.Id_measure = Convert.ToInt32(textBox_Measure.Text);
                    _tempFood.Price = Convert.ToDouble(textBox_Price.Text);
                    _tempFood.Photo = textBox_Photo.Text;

                    DatabaseControl.UpdateFood(_tempFood);

                    MessageBox.Show("Изменения успешно внесены!");
                    Close();

                }
            else
            {
                MessageBox.Show("Введены не все данные");
            }
        }

        private void foodEditCancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
