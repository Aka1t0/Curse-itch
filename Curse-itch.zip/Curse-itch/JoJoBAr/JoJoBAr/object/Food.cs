using System;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using NpgsqlTypes;

namespace JoJoBAr
{
    public class Food
    {
        [Key]
        public int Id_food { get; set; }
        public string Food_name { get; set; }
        public string Cooking_time { get; set; }
        public string Definition { get; set; }
        public bool Cooking_place { get; set; }
        public double Weight { get; set; }
        [ForeignKey("Measure_entity")]
        public int Id_measure { get; set; }
        public double Price { get; set; }
        public string Photo { get; set; }
        public Measure Measure_entity { get; set; }
        public List<Order_and_food> Order_and_food_entities { get; set; }
        public List<Food_and_product> Food_and_product_entities { get; set; }
    }


}
