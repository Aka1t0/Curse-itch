﻿using System;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JoJoBAr
{
    public class Client_card
    {
        [Key]
        public int Id_client_card { get; set; }
        public string FIO { get; set; }
        public string Phone { get; set; }
        public double Bonus { get; set; }
        public List<Order> Order_entities { get; set; }
    }
}
