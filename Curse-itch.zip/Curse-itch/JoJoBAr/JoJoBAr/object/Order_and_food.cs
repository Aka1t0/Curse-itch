﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JoJoBAr
{
    public class Order_and_food
    {
        [Key]
        public int Id_order_and_food { get; set; }

        [ForeignKey ("Order_entity")]
        public int Id_order { get; set; }

        [ForeignKey("Food_entity")]
        public int Id_food { get; set; }
        public Order Order_entity { get; set; }
        public Food Food_entity { get; set; }

    }
}
