﻿using System;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Npgsql.EntityFrameworkCore.PostgreSQL.Storage.Internal.Mapping;
using NpgsqlTypes;

namespace JoJoBAr
{
    public class Table
    {
        [Key]
        public int Id_table { get; set; }
        public int Seats { get; set; }
        public bool Reserved { get; set; }
        public List<Order> Order_entities { get; set; }
        public List<Table_shedule> Table_shedule_entities { get; set; }
    }
}
