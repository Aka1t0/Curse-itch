﻿using System;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Npgsql.EntityFrameworkCore.PostgreSQL.Storage.Internal.Mapping;
using NpgsqlTypes;

namespace JoJoBAr
{
    public class Table_shedule
    {
        [Key]
        public int Id_table_shedule { get; set; }

        [ForeignKey ("Table_entity")]
        public int Id_table { get; set; }

        public string Reservation_time_start { get; set; }
        public string Reservation_interval { get; set; }
        public Table Table_entity { get; set; }
    }
}
