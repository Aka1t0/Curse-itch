﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace JoJoBAr
{
    public class DbAppContext: DbContext
   {
        public DbSet<User> User { get; set; }
        public DbSet<Product_in_stock> Product_in_stock { get; set; }
        public DbSet<Client_card> Client_card { get; set; }
        public DbSet<Food> Food { get; set; }
        public DbSet<Order> Order { get; set; }
        public DbSet<Table> Table { get; set; }
        public DbSet<Food_and_product> Food_and_product{ get; set; }
        public DbSet<Order_and_food> Order_and_food { get; set; }
        public DbSet<Measure> Measure { get; set; }

        public DbSet<Table_shedule> Table_shedule { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql(
                //"Host=localhost;Username=postgres;Password=22345621;Database=Bar_bd");
                "Host=localhost;Username=postgres;Password=22345621;Database=Bar_bd");

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Order>().HasOne(o => o.User_entity).WithMany(o => o.Order_entities);

            modelBuilder.Entity<Order>().HasOne(o => o.Table_entity).WithMany(o => o.Order_entities);

            modelBuilder.Entity<Order>().HasOne(o => o.Client_card_entity).WithMany(o => o.Order_entities);

            modelBuilder.Entity<Order_and_food>().HasOne(of => of.Order_entity).WithMany(of => of.Order_and_food_entities);

            modelBuilder.Entity<Order_and_food>().HasOne(of => of.Food_entity).WithMany(of => of.Order_and_food_entities);

            modelBuilder.Entity<Food_and_product>().HasOne(of => of.Food_entity).WithMany(of => of.Food_and_product_entities);

            modelBuilder.Entity<Food_and_product>().HasOne(of => of.Product_in_stock_entity).WithMany(of => of.Food_and_product_entities);

            modelBuilder.Entity<Food_and_product>().HasOne(of => of.Measure_entity).WithMany(of => of.Food_and_product_entities);

            modelBuilder.Entity<Food>().HasOne(of => of.Measure_entity).WithMany(of => of.Food_entities);

            modelBuilder.Entity<Product_in_stock>().HasOne(of => of.Measure_entity).WithMany(of => of.Product_in_stock_entities);

            modelBuilder.Entity<Table_shedule>().HasOne(of => of.Table_entity).WithMany(of => of.Table_shedule_entities);

        }
    }
}
